
import 'package:flutter/material.dart';

void main() => runApp(AlizaaApp());

class AlizaaApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Alizaa',
      theme: ThemeData(
        primarySwatch: Colors.purple,
      ),
      home: AlizaaHomePage(),
    );
  }
}

class AlizaaHomePage extends StatefulWidget {
  @override
  _AlizaaHomePageState createState() => _AlizaaHomePageState();
}

class _AlizaaHomePageState extends State<AlizaaHomePage> {
  String response = 'Hi! I am Alizaa.';

  void listenToUser() {
    setState(() {
      response = 'Listening to your voice...';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Alizaa AI Assistant'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(response, style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: listenToUser,
              child: Text('Talk to Alizaa'),
            )
          ],
        ),
      ),
    );
  }
}
